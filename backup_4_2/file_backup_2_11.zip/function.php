<?php 
function checkbox($var,$val){
foreach($var as $v){
  if($v==$val)
    return 'checked="checked"';
 }
}

function checkbox1($var,$val){
foreach($var as $v){
  if($v==$val)
    return 'checked="checked"';
 }
}
function number() 
{
 if(!isset($_GET['page']) || $_GET['page']=="")
  $count=0;
 else
  $count=($_GET['page']-1)*10;
  return $count;
}

function number2() 
{
 if(!isset($_GET['page']) || $_GET['page']=="")
  $count=0;
 else
  $count=($_GET['page']-1)*20;
  return $count;
}

function strupp($str)
  {
   $str=trim(strtoupper($str));
   return $str;
  }
  
function salesman_name($id){
$query=mysql_query("SELECT name FROM department_list where (`id`='$id') ");
$value=mysql_fetch_array($query);
$salesman_name=$value['name'];
return $salesman_name;
} 				
?>




<?php
function select($col1,$col2,$table)
  {   
  
   $query=mysql_query("select $col1,$col2 from $table order by '$col1' ");
   while($data=mysql_fetch_array($query))
     {
   ?>
  <option value="<?php echo $data['name'];  ?>"><?php echo $data['name'];  ?></option>
  
 <?php }  
  }  
?>



<?php
function selected($col1,$col2,$table,$selected)
  { 
   $query=mysql_query("select $col1,$col2 from $table");
   while($data=mysql_fetch_array($query))
     {
   ?>
  <option <?php if($selected==$data['name']) echo 'selected="selected"'; ?> value="<?php echo $data['name'];  ?>"><?php echo $data['name'];  ?></option>
  
 <?php } 
  echo '</select>'; 
  }
function salesman_area($id)
 {
	$query=mysql_query("select * from working_area WHERE salesman_id='$id'") or die(mysql_error());
	while($data=mysql_fetch_assoc($query))
	{
	 $state[]=$data['state'];
	 $district[]=$data['district'];
	 $city[]=unserialize($data['city']);
	 //echo '<pre>';print_r($data);
	
	}
	$state=array_unique($state);
	$district=array_unique($district);
	$std="";
	$did="";
	$cid="";
	$queryresult="";
	foreach($state as $st)
	  $std .="'".$st."',";
	  $std=rtrim($std,",");
	foreach($district as $di)
	  $did .="'".$di."',";
	  $did=rtrim($did,",");
	$size=sizeof($city);
	for($i=0;$i<$size; $i++)
	  {
	   foreach($city[$i] as $ci)
		 $cid .="'".$ci."',";  
	  }
	$cid=rtrim($cid,",");
	  
	if($std!="")
	  $queryresult .=" AND state IN ($std) ";
	if($did!="")
	  $queryresult .=" AND district IN ($did) ";
	if($cid!="")
	  $queryresult .=" AND city IN ($cid) "; 
	
	if( $queryresult!="")
	  return $queryresult;
	else
	  return "AND status='00' ";
	
 
 
 
 }
  
?>
