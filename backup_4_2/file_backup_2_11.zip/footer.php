<!--Footer-->
<div class="footer-main">
<div class="footer">
<div class="footer-left">
<div class="footer-text01">Copyright 2015 Mascot Education Pvt. Ltd. All Right Reserved</div>
</div>
<div class="footer-right">
<div class="footer-text01">Designed & Developed by <a href="http://danstring.com/" target="_blank">Danstring Technologies Pvt. Ltd.</a></div>
</div>
</div>
</div>
<!--Footer End-->



</div>

</body>
</html>