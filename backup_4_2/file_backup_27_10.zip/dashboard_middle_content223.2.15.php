<div class="middle-body-two-main">
<div class="middle-body-two">
<div class="mbt-box01">
<div class="mbt-box0201"><div class="mbt-box-text01">Skyland</div></div>
<div class="mbt-box0101">
<div class="mbt-box-heading-text">Birthday
<span class="mbt-box-view-all"><a href="#">View All</a></span>
</div>
<div class="mbt-box-text02">
<ol style="padding:0 0 0 15px; line-height:20px; margin:5px 0 0 0;">
<li>Vikas from Danstring (1/1/2015)</li>
<li>Bipin from DAV (1/1/2015)</li>
<li>Sujit from GBSSS (1/1/2015)</li>
</ol>
</div>



<div class="mbt-box-heading-text">Anniversary
<span class="mbt-box-view-all"><a href="#">View All</a></span>
</div>
<div class="mbt-box-text02">
<ol style="padding:0 0 0 15px; line-height:20px;  margin:5px 0 0 0;">
<li>Vikas from Danstring (1/1/2015)</li>
<li>Bipin from Danstring (1/1/2015)</li>
<li>Sujit from Danstring (1/1/2015)</li>
</ol>
</div>
</div>
</div>
<div class="mbt-box02">

<div class="mbt-box0201"><div class="mbt-box-text01">Reports</div></div>
<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Vikas</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>
<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Sujit</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>

<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Bipin</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>


<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Vikas</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>
<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Sujit</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>
<div class="mbt-box0202">
<div class="report-img-box"><img src="images/login-page-images/report1.jpg" width="60" height="60" /></div>
<div class="report-img-text">
<div class="report-img-heading">Report Bipin</div>
<div class="report-img-text01">Demo text Demo text Demo text Demo text Demo text Demo text Demo text Demo text</div>
</div>

</div>




</div>

</div>
</div>