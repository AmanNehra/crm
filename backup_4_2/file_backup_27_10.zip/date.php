<?php include('header.php');?><!doctype html>
<html lang="en">
<body>
<p>Date: <input type="text" id="datepicker" size="30"></p>
</body>
</html>