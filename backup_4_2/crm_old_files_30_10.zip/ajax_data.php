<?php
require_once('config.php');
if(isset($_GET['q']))
 {
 	$id=$_GET['q'];	 
	$query=mysql_query("SELECT * FROM location_maste_info_list WHERE id= '$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query);   
	$string=$value['city'].'#'.$value['district'].'#'.$value['state'].'#'.$value['country'].'#'.$value['pin'].'#'.$value['std'];
	
	echo $string; die();
 }

if(isset($_GET['p']))
 {
 	$id=$_GET['p'];	 
	$query=mysql_query("SELECT district,state FROM location_maste_info_list WHERE id= '$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query);   
	$string=$value['district'].'#'.$value['state'];
	
	echo $string; die();
 }
 
 if(isset($_GET['r']))
 {
 	$id=$_GET['r'];	 
	$query=mysql_query("SELECT distict,state FROM bank_details_list WHERE id= '$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query);   
	$string=$value['distict'].'#'.$value['state'];
	
	echo $string; die();
 }
if(isset($_GET['s']))
 {
 	$id=$_GET['s'];	 
	$query=mysql_query("SELECT subject,class FROM item_master_list WHERE id= '$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query);   
	$string=$value['subject'].'#'.$value['class'];
	
	echo $string; die();
 }
 
 if(isset($_GET['pass']))
 {
 	$id=$_GET['pass'];	 
	$query=mysql_query("SELECT user_decrypt FROM dan_users WHERE id= '$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query); 
	echo $value['user_decrypt']; die();
 }

 if(isset($_GET['exe']))
 {
 	$id=$_GET['exe'];
		 
	$query=mysql_query("SELECT designation FROM department_list WHERE id='$id' ") or die(mysql_error());
	$value=mysql_fetch_array($query); 
	echo $value['designation']; die();
	
 }
 if(isset($_GET['ser']))
 {
 	$ser=$_GET['ser'];
	$string="";	 
	$query=mysql_query("SELECT item_name FROM item_master_list WHERE subject= '$ser' ") or die(mysql_error());
  while($value=mysql_fetch_array($query) )
	  {   $string.=$value['item_name']; 
	    $string.="#"; 
	  }
	echo $string; die();
 }
?>