<!-- start footer -->         
<div id="footer">
<!-- <div id="footer-pad">&nbsp;</div> -->
	<!--  start footer-left -->
	<div id="footer-left">
	&copy; Copyright 2014 <a href="index.php" target="_blank"> "http://www.skyland.co.in"</a> , All rights reserved.<div style="float:right;"></div></div>
	<!--  end footer-left -->
	<div class="clear">&nbsp;</div>
</div>
<!-- end footer --> 
</body>
</html>