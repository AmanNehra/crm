<?php 
function checkbox($var,$val){
foreach($var as $v){
  if($v==$val)
    return 'checked="checked"';
 }
}

function checkbox1($var,$val){
foreach($var as $v){
  if($v==$val)
    return 'checked="checked"';
 }
}
function number() 
{
 if(!isset($_GET['page']) || $_GET['page']=="")
  $count=0;
 else
  $count=($_GET['page']-1)*10;
  return $count;
}

function number2() 
{
 if(!isset($_GET['page']) || $_GET['page']=="")
  $count=0;
 else
  $count=($_GET['page']-1)*20;
  return $count;
}

function strupp($str)
  {
   $str=trim(strtoupper($str));
   return $str;
  }
  
function salesman_name($id){
$query=mysql_query("SELECT name FROM department_list where (`id`='$id') ");
$value=mysql_fetch_array($query);
$salesman_name=$value['name'];
return $salesman_name;
} 				
?>




<?php
function select($col1,$col2,$table)
  {   
  
   $query=mysql_query("select $col1,$col2 from $table order by '$col1' ");
   while($data=mysql_fetch_array($query))
     {
   ?>
  <option value="<?php echo $data['name'];  ?>"><?php echo $data['name'];  ?></option>
  
 <?php }  
  }  
?>



<?php
function selected($col1,$col2,$table,$selected)
  { 
   $query=mysql_query("select $col1,$col2 from $table");
   while($data=mysql_fetch_array($query))
     {
   ?>
  <option <?php if($selected==$data['name']) echo 'selected="selected"'; ?> value="<?php echo $data['name'];  ?>"><?php echo $data['name'];  ?></option>
  
 <?php } 
  echo '</select>'; 
  }
  
?>
